import { NextResponse } from "next/server";
import { validateSession } from "@/lib/auth/session";
import {
  MockupGenerationError,
  createMockupJobForDraftDesign,
  loadMockupGenerationContext,
  prepareMockupGeneration,
  resolvePrimaryDraftDesign,
} from "@/lib/mockup/generation";

export async function POST(request: Request) {
  const session = await validateSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await request.json();
  const { draftId } = body;
  if (!draftId) return NextResponse.json({ error: "Missing draftId" }, { status: 400 });

  try {
    const context = await loadMockupGenerationContext(draftId, session.tenantId);
    const prepared = await prepareMockupGeneration(context);
    const result = await createMockupJobForDraftDesign(
      context,
      prepared,
      resolvePrimaryDraftDesign(context),
    );

    return NextResponse.json({
      jobId: result.jobId,
      totalImages: 0,
      status: result.status,
      provider: "printify",
      draftDesignId: result.draftDesignId,
      designId: result.designId,
    });
  } catch (error) {
    if (error instanceof MockupGenerationError) {
      return NextResponse.json(
        { error: error.message, code: error.code, ...error.details },
        { status: error.status },
      );
    }
    const message = error instanceof Error ? error.message : "Unknown Printify error";
    console.error("Printify real mockup generation failed:", error);
    return NextResponse.json(
      {
        error: `Printify không tạo được mockup thật: ${message}`,
        code: "PRINTIFY_REAL_MOCKUP_FAILED",
      },
      { status: 502 },
    );
  }
}
