"use client";

import {
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  Palette,
  Plus,
  Settings,
  Store,
  XCircle,
} from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { toast } from "sonner";

interface StoreData {
  id: string;
  name: string;
  shopifyDomain: string;
  printifyShopId: string | null;
  status: "ACTIVE" | "TOKEN_EXPIRED" | "ERROR";
  lastHealthCheck: string | null;
  colors: Array<{ id: string; name: string; hex: string; enabled?: boolean }>;
  templates: Array<{ id: string; name: string }>;
  presetStatus?: { ready: boolean; missing: string[]; completionPercent: number };
  createdAt: string;
}

interface Props {
  initialStores: StoreData[];
  canManageStores: boolean;
}

export default function StoresClient({
  initialStores,
  canManageStores,
}: Props) {
  const [stores] = useState<StoreData[]>(initialStores);
  const isAdmin = canManageStores;

  async function handleDelete(storeId: string, storeName: string) {
    // Native confirm vẫn dùng cho destructive — user phải chủ động click OK,
    // tránh accidental deletion từ keyboard shortcut. Toast confirm có thể auto-dismiss.
    if (!confirm(`Bạn chắc muốn xóa store "${storeName}"?\n\nThao tác không thể hoàn tác.`)) return;
    try {
      const res = await fetch(`/api/stores/${storeId}`, { method: "DELETE" });
      if (res.ok) {
        toast.success(`Đã xóa store "${storeName}"`);
        window.location.reload();
      } else {
        toast.error("Lỗi khi xóa store");
      }
    } catch {
      toast.error("Lỗi khi xóa store");
    }
  }

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="page-title">Stores</h1>
          <p className="page-subtitle">
            {isAdmin
              ? "Quản lý kết nối Shopify + Printify"
              : "Xem store đã sẵn sàng để tạo listing"}
          </p>
        </div>
        {isAdmin && (
          <Link href="/stores/new" className="btn btn-primary">
            <Plus size={16} />
            Kết nối Store
          </Link>
        )}
      </div>

      {/* Store List */}
      {stores.length === 0 ? (
        <div className="card" style={{ padding: "60px", textAlign: "center" }}>
          <Store size={48} style={{ margin: "0 auto", opacity: 0.3, marginBottom: "16px" }} />
          <h3 style={{ marginBottom: "8px", fontWeight: 700 }}>Chưa có Store nào</h3>
          <p style={{ opacity: 0.6, marginBottom: "24px" }}>
            {isAdmin
              ? "Kết nối Shopify store đầu tiên để bắt đầu tạo sản phẩm"
              : "Vui lòng liên hệ Admin để kết nối Store"}
          </p>
          {isAdmin && (
            <Link href="/stores/new" className="btn btn-primary">
              <Plus size={16} />
              Kết nối Store đầu tiên
            </Link>
          )}
        </div>
      ) : (
        <div style={{ display: "grid", gap: "16px" }}>
          {stores.map((store) => (
            <div key={store.id} className="card" style={{ padding: "24px" }}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4" style={{ flex: 1 }}>
                  <div
                    style={{
                      width: 48,
                      height: 48,
                      borderRadius: "var(--radius-md)",
                      backgroundColor: "var(--bg-tertiary)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Store size={22} style={{ opacity: 0.6 }} />
                  </div>

                  <div style={{ flex: 1 }}>
                    <div className="flex items-center gap-3" style={{ marginBottom: "4px" }}>
                      <span style={{ fontWeight: 700, fontSize: "1.1rem" }}>{store.name}</span>
                      <StatusBadge status={store.status} />
                    </div>
                    <div style={{ fontSize: "0.875rem", opacity: 0.6 }}>
                      {isAdmin ? (
                        <a
                          href={`https://${store.shopifyDomain}/admin`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1"
                          style={{ color: "inherit", textDecoration: "none" }}
                        >
                          {store.shopifyDomain}
                          <ExternalLink size={12} />
                        </a>
                      ) : (
                        <span>{store.shopifyDomain}</span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-6" style={{ fontSize: "0.875rem" }}>
                    <div className="flex items-center gap-2" style={{ opacity: 0.6 }}>
                      <Palette size={14} />
                      <span>{store.colors.filter((c) => c.enabled !== false).length} màu</span>
                    </div>
                    <div style={{ opacity: 0.6 }}>
                      {store.printifyShopId ? "✅ Printify" : "❌ Chưa kết nối Printify"}
                    </div>
                    {store.presetStatus && (
                      <div style={{ minWidth: 110 }}>
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 6,
                            fontSize: "0.72rem",
                            marginBottom: 2,
                          }}
                        >
                          <span style={{ opacity: 0.6, fontWeight: 600 }}>Preset</span>
                          <span
                            style={{
                              fontWeight: 700,
                              color: store.presetStatus.ready
                                ? "var(--color-wise-green)"
                                : "#f59e0b",
                            }}
                          >
                            {store.presetStatus.completionPercent}%
                          </span>
                        </div>
                        <div style={{ height: 4, borderRadius: 2, background: "var(--bg-inset)" }}>
                          <div
                            style={{
                              height: "100%",
                              borderRadius: 2,
                              width: `${store.presetStatus.completionPercent}%`,
                              background: store.presetStatus.ready
                                ? "var(--color-wise-green)"
                                : "#f59e0b",
                              transition: "width 0.3s",
                            }}
                          />
                        </div>
                      </div>
                    )}
                    {store.lastHealthCheck && (
                      <div style={{ opacity: 0.4, fontSize: "0.8rem" }}>
                        Check: {new Date(store.lastHealthCheck).toLocaleDateString("vi-VN")}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {isAdmin && (
                    <>
                      <Link
                        href={`/stores/${store.id}/config`}
                        className="btn btn-secondary"
                        style={{ padding: "8px 12px" }}
                      >
                        <Settings size={14} />
                        Cấu hình
                      </Link>
                      <button
                        onClick={() => handleDelete(store.id, store.name)}
                        className="btn btn-danger"
                        style={{ padding: "8px 12px" }}
                        type="button"
                      >
                        Xóa
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: StoreData["status"] }) {
  const configs = {
    ACTIVE: { icon: <CheckCircle2 size={14} />, label: "Hoạt động", className: "badge-success" },
    TOKEN_EXPIRED: {
      icon: <AlertTriangle size={14} />,
      label: "Token hết hạn",
      className: "badge-warning",
    },
    ERROR: { icon: <XCircle size={14} />, label: "Lỗi", className: "badge-danger" },
  };
  const config = configs[status];
  return (
    <span
      className={`badge ${config.className}`}
      style={{ display: "inline-flex", alignItems: "center", gap: "4px" }}
    >
      {config.icon}
      {config.label}
    </span>
  );
}
