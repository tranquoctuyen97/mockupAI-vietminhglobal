import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const layoutSource = readFileSync("src/app/(authed)/wizard/[draftId]/layout.tsx", "utf8");
const step2Source = readFileSync("src/app/(authed)/wizard/[draftId]/step-2/page.tsx", "utf8");

test("wizard layout blocks only unpaired suffix designs", () => {
  assert.match(layoutSource, /pairDesigns/);
  assert.match(layoutSource, /pairing\.unpaired\.length\s*>\s*0/);
  assert.doesNotMatch(layoutSource, /selectedDesignCount\s*!==\s*pairCount\s*\*\s*2/);
});

test("step 2 explains that independent designs publish separately", () => {
  assert.match(
    step2Source,
    /Design có tên sáng\/tối sẽ tự ghép cặp\. Design đơn lẻ sẽ publish riêng\./,
  );
});
