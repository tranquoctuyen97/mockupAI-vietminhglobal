import { GoogleGenAI, Type } from "@google/genai";
import {
  ContentGenerator,
  ContentInput,
  ContentOutput,
  ProductOrganizationInput,
  ProductOrganizationOutput,
} from "../types";
import { SYSTEM_PROMPT_POD_LISTING } from "../prompts/pod-listing";
import {
  buildListingUserPrompt,
  buildOrganizationUserPrompt,
  parseListingContentJson,
  parseProductOrganizationJson,
} from "./shared";

export class GeminiProvider implements ContentGenerator {
  private ai: GoogleGenAI;
  private modelName: string;

  constructor(
    apiKey: string,
    modelName: string = "gemini-2.5-flash",
    private systemPrompt: string = SYSTEM_PROMPT_POD_LISTING,
  ) {
    this.ai = new GoogleGenAI({ apiKey });
    this.modelName = modelName;
  }

  async generate(input: ContentInput): Promise<ContentOutput> {
    // Note: Gemini SDK structured output
    const response = await this.ai.models.generateContent({
      model: this.modelName,
      contents: buildListingUserPrompt(input),
      config: {
        systemInstruction: this.systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: {
              type: Type.STRING,
              description: "Product title, max 60 chars",
            },
            description: {
              type: Type.STRING,
              description: "HTML description, 150-200 words",
            },
            tags: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Exactly 15 relevant SEO tags, lowercase, distinct",
            },
            altText: {
              type: Type.STRING,
              description: "Image alt text, max 125 chars",
            },
          },
          required: ["title", "description", "tags", "altText"],
        },
      },
    });

    const tokensIn = response.usageMetadata?.promptTokenCount || 0;
    const tokensOut = response.usageMetadata?.candidatesTokenCount || 0;

    const resultText = response.text;
    if (!resultText) {
      throw new Error("Empty response from AI");
    }

    try {
      return parseListingContentJson(resultText, { tokensIn, tokensOut });
    } catch (error) {
      console.error("Failed to parse Gemini output:", resultText);
      throw new Error("AI returned malformed JSON");
    }
  }

  async optimizeProductOrganization(
    input: ProductOrganizationInput,
  ): Promise<ProductOrganizationOutput> {
    const response = await this.ai.models.generateContent({
      model: this.modelName,
      contents: buildOrganizationUserPrompt(input),
      config: {
        systemInstruction: this.systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tags: { type: Type.ARRAY, items: { type: Type.STRING } },
            collections: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ["tags", "collections"],
        },
      },
    });

    const resultText = response.text;
    if (!resultText) throw new Error("Empty response from AI");

    return parseProductOrganizationJson(resultText, {
      tokensIn: response.usageMetadata?.promptTokenCount || 0,
      tokensOut: response.usageMetadata?.candidatesTokenCount || 0,
    });
  }
}
