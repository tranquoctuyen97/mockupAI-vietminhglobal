export function getPublicOrigin(requestOrigin: string): string {
  const url = process.env.NEXT_PUBLIC_APP_URL;
  return (url || requestOrigin).replace(/\/$/, "");
}

export function isTextContent(contentType: string): boolean {
  return (
    contentType.includes("text/html") ||
    contentType.includes("text/javascript") ||
    contentType.includes("application/javascript") ||
    contentType.includes("text/css")
  );
}

export function rewriteApiUrls(body: string, host: string): string {
  return body.replace(/https?:\/\/api-inkhub-v2\.grabink\.co/g, `${host}/api/inkhub-api`);
}

// Rewrite absolute paths (src="/..." href="/...") to go through the proxy.
// Skips protocol-relative (//...) and full URLs (https://...).
export function rewriteAbsolutePaths(html: string, proxyBase: string): string {
  return html
    .replace(/(src|href)="\/(?!\/)/g, `$1="${proxyBase}/`)
    .replace(/(src|href)='\/(?!\/)/g, `$1='${proxyBase}/`);
}

export function injectTokenScript(html: string, token: string, orgId: string): string {
  if (!html.includes("</head>")) return html;
  const script = `<script>localStorage.setItem('token','${token}');localStorage.setItem('organizationId','${orgId}');history.replaceState({},'','/orders');</script>`;
  return html.replace("</head>", `${script}</head>`);
}

// Rewrite root-relative static asset paths in JS/CSS string literals to go through the proxy.
// Matches quoted strings like "/logo.png" or "/icon.ico?v=2". Skips already-proxied paths.
export function rewriteRootAssets(body: string, proxyBase: string): string {
  return body.replace(
    /(["'])(\/(?!api\/)(?:[^"'?#]*\.)(?:ico|png|jpg|jpeg|gif|svg|webp|woff2?|ttf|eot|otf)(?:\?[^"']*)?)\1/g,
    `$1${proxyBase}$2$1`,
  );
}
